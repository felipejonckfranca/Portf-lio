package com.example.sa;

public class Pontuações {
    int pontuação_1;
    int pontuação_2;
    int pontuação_3;
    int pontuação_4;
    int pontuação_5;
    int pontuação_6;
    int pontuação_7;
    int pontuação_8;

}