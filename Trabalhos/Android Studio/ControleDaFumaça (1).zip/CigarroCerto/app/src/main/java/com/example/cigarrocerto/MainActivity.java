package com.example.cigarrocerto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    EditText login, passwd;
    boolean sla = false;
    public static String nome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);getSupportActionBar().hide();

        login = findViewById(R.id.login);
        passwd = findViewById(R.id.senha);
        nome = String.valueOf(login.getText());

    }



    public void botaoo_entrar(View v){
        sla = false;
        entrar();
    }

    public void entrar(){

        if(!sla){
            verifica_user_login();
        }else if(sla){
            mudaTela();
        }
    }

    public void botao_cadastro(View patolino){
        Intent i = new Intent(this, Cadastro.class);
        startActivity(i);
    }

    public void mudaTela(){
        Intent intent = new Intent(this, Fumanu.class);
        startActivity(intent);
    }

    public void print (String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    public void verifica_user_login(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Usuarios");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String l = login.getText().toString();
                String s = passwd.getText().toString();
                for (DataSnapshot d: snapshot.getChildren()){
                    if(d.getValue(Usuario.class).getLogin().equals(l) && d.getValue(Usuario.class).getSenha().equals(s)){

                        sla = true;

                        entrar();
                        Fumanu.u = d.getValue(Usuario.class);
                        break;
                    }

                }
                if(!sla){
                    print("usuario não cadastrado");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }}