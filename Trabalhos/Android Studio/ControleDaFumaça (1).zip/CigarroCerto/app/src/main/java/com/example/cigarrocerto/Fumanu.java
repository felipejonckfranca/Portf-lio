package com.example.cigarrocerto;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;


public class Fumanu extends AppCompatActivity {
    TextView cigashoje, canetashoje, cigarrostoday;
    static Usuario u;
    RadioButton rbC, rbCa;
    int maximocigarro;
    int dia;
    int ultimodia;
    AlertDialog.Builder alerta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fumanu);
        getSupportActionBar().hide();
        dia = LocalDateTime.now().getDayOfYear();

        alerta = new AlertDialog.Builder(this);
        ultimodia = u.ulitmo_dia;

        cigashoje = findViewById(R.id.fumadoscigarro);
        cigashoje.setText(String.valueOf(u.cigarros));
        canetashoje = findViewById(R.id.cigarrosjafoi);
        canetashoje.setText(String.valueOf(u.canetas));
        rbC = findViewById(R.id.rbCigarroNormal);
        rbCa = findViewById(R.id.rbCigarroEletronico);
        cigarrostoday = findViewById(R.id.cigastoday);
        cigarrostoday.setText(String.valueOf(u.cigarros_hoje));

        maximocigarro = 15;

        if(u.cigarros_hoje > maximocigarro){
            alerta.setTitle("Cigarro");
            alerta.setMessage("Você está fumando demais!");
            alerta.show();
        }

        if (u.ulitmo_dia != dia){
            reset();
        }
    }

public void reset(){
        u.cigarros_hoje = 0;
}



    public void fumar(View v){

        RadioButton a = rbC;
        RadioButton b = rbCa;
        if (a.isChecked()){
            u.cigarros ++;

            u.setUlitmo_dia(dia);
            u.cigarros_hoje ++;
            u.salvar_bd();

        }else if (b.isChecked()){
            u.canetas ++;

            u.setUlitmo_dia(dia);
            u.cigarros_hoje ++;
            u.salvar_bd();

        }else{
            Toast.makeText(this,"Selecione uma opção.",Toast.LENGTH_SHORT).show();

        }

    }

}