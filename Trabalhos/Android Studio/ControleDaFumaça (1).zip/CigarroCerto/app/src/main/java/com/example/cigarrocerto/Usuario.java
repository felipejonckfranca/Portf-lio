package com.example.cigarrocerto;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Usuario {

    public String login;
    public String senha;
    public int cigarros = 0;
    public int canetas = 0;
    public int cigarros_hoje = 0;
    public int ulitmo_dia;

    public Usuario(String login, String senha, int cigarros) {
        this.login = login;
        this.senha = senha;
        this.cigarros = cigarros;
    }

    public Usuario(String login, String senha, int cigarros, int canetas,int ulitmo_dia, int cigarros_hoje) {
        this.login = login;
        this.senha = senha;
        this.cigarros = cigarros;
        this.canetas = canetas;
        this.ulitmo_dia = ulitmo_dia;
        this.cigarros_hoje = cigarros_hoje;
    }

    public Usuario() {
    }


    public int getCanetas() {
        return canetas;
    }

    public void setCanetas(int canetas) {
        this.canetas = canetas;
    }

    public int getUlitmo_dia() {
        return ulitmo_dia;
    }

    public void setUlitmo_dia(int ulitmo_dia) {
        this.ulitmo_dia = ulitmo_dia;
    }

    public void salvar_bd(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("Usuarios").child(login).setValue(this);
    }



    public int getCigarros() {return cigarros;}

    public void setCigarros(int cigarros) {this.cigarros = cigarros;}

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}

